"use strict";
import{dN as e,dO as o}from"./js/core.BM8EU4h5.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
