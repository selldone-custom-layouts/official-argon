"use strict";
import{dK as e,dL as o}from"./js/core.CtvZEB9H.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
