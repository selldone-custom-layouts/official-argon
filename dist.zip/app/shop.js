"use strict";
import{dN as e,dO as o}from"./js/core.B2ycobZZ.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
