"use strict";
import{dR as e,dS as o}from"./js/core.B4LhAGow.js";const t=Object.freeze(Object.defineProperty({__proto__:null,LandingRender:o,SetupPageBuilder:e},Symbol.toStringTag,{value:"Module"}));export{t as i};
