"use strict";
import{E as s}from"./core.Bux2AwBr.js";const t={methods:{showFullscreen(e){s.$emit("show:fullscreen",e)}}};export{t as I};
