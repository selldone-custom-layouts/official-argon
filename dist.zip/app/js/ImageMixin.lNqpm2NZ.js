"use strict";
import{E as s}from"./core.D8_eOxKk.js";const t={methods:{showFullscreen(e){s.$emit("show:fullscreen",e)}}};export{t as I};
