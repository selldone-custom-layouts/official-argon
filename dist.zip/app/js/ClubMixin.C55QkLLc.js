"use strict";
import{C as t}from"./core.D8_eOxKk.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
