"use strict";
import{E as s}from"./core.BM8EU4h5.js";const t={methods:{showFullscreen(e){s.$emit("show:fullscreen",e)}}};export{t as I};
