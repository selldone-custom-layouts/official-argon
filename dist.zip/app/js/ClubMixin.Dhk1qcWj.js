"use strict";
import{C as t}from"./core.DMj_fTPW.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
