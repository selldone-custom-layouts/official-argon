"use strict";
import{E as s}from"./core.DMj_fTPW.js";const t={methods:{showFullscreen(e){s.$emit("show:fullscreen",e)}}};export{t as I};
