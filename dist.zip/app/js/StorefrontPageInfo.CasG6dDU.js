"use strict";
import t from"./SFooterSection.B6zDZC9E.js";import{a3 as n,_ as r,o as s,c as a,h as c,r as p}from"./core.DMj_fTPW.js";const i={name:"StorefrontPageInfo",components:{SFooterSection:t},mixins:[n],props:{}};function f(o,m,_,l,d,u){const e=p("s-footer-section");return o.isMobile?(s(),a(e,{key:0})):c("",!0)}const $=r(i,[["render",f]]);export{$ as default};
