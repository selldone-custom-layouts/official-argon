"use strict";
import{C as t}from"./core.KcbA9yjE.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
