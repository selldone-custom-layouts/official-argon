"use strict";
import{C as t}from"./core.BpHSSoI2.js";const r={methods:{getCustomerClubLevel(e){return t.Levels[e]}}};export{r as C};
